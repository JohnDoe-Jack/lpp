#!/bin/bash

rm *.gcda *.gcno *.o *.gcov tc
